#!/bin/bash
#####################################################################
#######            Upgrade Script                           #########
#####################################################################
umask 022
initializeFiles2()
{
	mkdir -p /etc/squid2
	mkdir -p /var/log/squid2
	mkdir -p /var/cache/squid2
	mkdir -p /var/spool/squid2
	touch /var/log/squid2/access.log
	touch /var/log/squid2/error.log
	touch /var/log/squid2/cache.log
	chmod 666 /var/log/squid2/access.log /var/log/squid2/error.log /var/log/squid2/cache.log
	echo > /etc/squid2/squiddb
	echo >/etc/squid2/squid.passwd
	mkdir -p /etc/squid2/conf.d/
	touch /etc/squid2/conf.d/sample.conf
	echo > /etc/squid2/squid.conf
	echo > /etc/squid2/blacklist.acl
}

installSquid()
{

	wget http://www.squid-cache.org/Versions/v4/squid-4.10.tar.gz
	tar -zxf squid-4.10.tar.gz
	cd squid-4.10
	./bootstrap.sh
	./configure --prefix=/usr/bin --includedir=${prefix}/include --mandir=${prefix}/share/man --infodir=${prefix}/share/info --localstatedir=/var --libexecdir=${prefix}/lib/squid2 --disable-maintainer-mode --disable-dependency-tracking --disable-silent-rules --enable-async-io --enable-icmp --enable-delay-pools --enable-useragent-log --enable-snmp --enable-http-violation --datadir=/usr/share/squid2 --sysconfdir=/etc/squid2 --libexecdir=/usr/lib/squid2 --mandir=/usr/share/man --enable-inline --enable-storeio=ufs,aufs,diskd,rock --enable-cache-digests --enable-icap-client  --enable-follow-x-forwarded-for --with-swapdir=/var/spool/squid2 --with-logdir=/var/log/squid2 -with-pidfile=/var/run/squid2.pid --with-filedescriptors=65536  --with-large-files --with-default-user=proxy --enable-build-info="Ubuntu linux" --enable-linux-netfilter CXXFLAGS="-DMAXTCPLISTENPORTS=8192"
	make
	make install

	wget https://raw.githubusercontent.com/revathivarun13/squidproxy/master/squid2.init -O squid2.init
	cp squid2.init /etc/init.d/squid2
	chmod +x /etc/init.d/squid2
	wget https://raw.githubusercontent.com/revathivarun13/squidproxy/master/squid2.service
	cp squid2.service /etc/systemd/system/squid2.service
	systemctl daemon-reload
	wget https://raw.githubusercontent.com/revathivarun13/squidproxy/master/squid2.conf
	cp -f squid2.conf /etc/squid2/squid.conf
	systemctl start squid2.service
	cd ..
}
upgradeDB()
{
	echo "Initialize Database structure. Please enter Password as root@2019 when prompted"
    cat upgradedb.sql | mysql -u root -p
}
initializeFiles2
installSquid
upgradeDB
cp -f /opt/squid/proxy.sh /opt/squid/proxy.sh.single
cp -f proxy.sh /opt/squid/proxy.sh
cp -f monitor.sh /opt/squid/monitor.sh
chmod +x /opt/squid/proxy.sh
chmod +x /opt/squid/monitor.sh