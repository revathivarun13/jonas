#!/bin/bash
#########################################################
#                                                       #
#                               Squid Proxy Script      #
#                               Prepared By: Varun      #
#                               Version 1.0             #
#                                                       #
#########################################################

###Global Variables
OS=`uname -s`
DISTRIB=`cat /etc/*release* | grep -i DISTRIB_ID | cut -f2 -d=`
SQUID_VERSION=4.8
BASEDIR="/opt/squid"
CONFIGDIR="/etc/squid"
CONFIGDIR2="/etc/squid2"
CONFIG_FILE="${BASEDIR}/config.cfg"
PASSWDMASTER="/etc/squid/squid.passwd"
BLACKLIST="/etc/squid/blacklist.acl"
MYSQLDB="squiddb"
MYSQLUSER="squid"
MYSQL_PWD="root@2019"
export MYSQL_PWD

if [ $# -eq 1 ]
then
        userid=`mysql -N -h localhost -u $MYSQLUSER $MYSQLDB -e "SELECT USERID FROM USERMASTER WHERE USERNAME='$1';"`
        if [ -z "$userid" ];then echo "User $1 Doesn't EXIST!!!";exit 32;fi
        ipids=`mysql -N -h localhost -u $MYSQLUSER $MYSQLDB -e "select IPID from PROXYMASTER where USERID=$userid;"`
		PXYID=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "select PXYID from PROXYMASTER where USERID=$userid limit 1;"`
        for IPID in $ipids
        do
                mysql -h localhost -u $MYSQLUSER $MYSQLDB -e "DELETE from PROXYMASTER WHERE IPID=$IPID;"
				mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "DELETE from PORTMASTER WHERE PXYID=$PXYID;"
                mysql -h localhost -u $MYSQLUSER $MYSQLDB -e "UPDATE IPMASTER SET STATUS=0 WHERE IPID=$IPID;"
        done
        mysql -N -h localhost -u $MYSQLUSER $MYSQLDB -e "DELETE from USERMASTER WHERE USERNAME='$1';"
        echo "User: $1 DELETED!!!!"
        rm -rf /etc/squid/conf.d/${userid}_*.conf
        systemctl reload squid
        exit 0
else
        echo > /dev/null
fi

checkRoot()
{
        if [ `id -u` -ne 0 ]
        then
                echo "SCRIPT must be RUN as root user"
                exit 13
        else
                echo "USER: root" 1>/dev/null
        fi
}
checkOS()
{
        if [ "$OS" == "Linux" ] && [ "$DISTRIB" == "Ubuntu" ]
        then
                echo "Operating System = $DISTRIB $OS" 1>/dev/null
        else
                echo "Please run this script on Ubuntu Linux" 1>/dev/null
                exit 12
        fi
}
checkSquid()
{
        dpkg-query --list squid >/dev/null 2>&1
        if [ `echo $?` -eq 0 ]
        then
                echo "Squid Installed" > /dev/null
        else
                apt-get install squid apache2-utils -y
        fi
        clear
}
printMenu()
{
        clear
        tput clear
        for I in {1..80};do tput cup 1 $I;printf "#";done
        printf "\n"
        R=2
        C1=1
        C2=45
        M=1
        while read LINE
        do
                tput cup $R $C1;printf "[$M]`echo $LINE | awk -F, '{print $1}'`"
                M=$((M+1))
                tput cup $R $C2;printf "[$M]`echo $LINE | awk -F, '{print $2}'`"
                M=$((M+1))
                R=$((R+1))
        done <<EOM
        ADD IP TO SERVER,SHOW AVAILABLE PROXIES
        ADD USER,ASSIGN PROXY TO USER
        SHOW USERS PROXY INFO,MODIFY USERS EXPIRY DATE
        DELETE IP FROM SERVER,DELETE USER PROXY
		DELETE USER,SHUTDOWN PROXY
		START PROXY,EXPORT AVAILABLE PROXY
		EXPORT USERS PROXY,ADD BLACK LIST
		SHOW BLACKLIST,DELETE BLACKLIST
		EXIT,FOR FUTURE USE
EOM
        for I in {1..11};do tput cup $I 80;printf "#";done
        for I in {1..80};do tput cup 13 $I;printf "#";done
        printf "\n"
        tput sgr0
}
createProxyFile()
{
        cd ${CONFIGDIR}/conf.d/
        printf "acl $1_$2 myip $1\n" >> $5
        printf "tcp_outgoing_address $1 $1_$2\n" >>$5
        printf "http_access allow $3 $1_$2 $3_$2\n" >> $5
}
Menu_1()
{
if [ ! -f ${CONFIG_FILE} ];then echo "Configuration File missing - Please contact developer!! ";fi
    INT=`cat ${CONFIG_FILE} | grep INTERFACE | awk -F"=" '{print $2}'`
    echo "Please Enter IP Address Block Details"
read -p "Enter New Subnet Name for your reference:" SUBNETNAME
if [ -z "${SUBNETNAME}" ];then return;fi
    read -p "Enter Starting IP address:" IPBLK
if [ -z "${IPBLK}" ];then return;fi
    read -p "Enter total number of IP :" N
    if [ -z "${N}" ];then return;fi
read -p "Enter Subnet[21|22|23|24]:" S
if [ -z "${S}" ];then return;fi
#S=24

    J=`echo ${IPBLK} | cut -f3 -d.`
    IP=`echo ${IPBLK} | cut -f1,2 -d.`
    M=0
    I=`echo ${IPBLK} | cut -f4 -d.`
   
mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "insert into SUBNETS (SUBNETNAME) values ('$SUBNETNAME');"
SUBID=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETID FROM SUBNETS ORDER BY SUBNETID DESC LIMIT 1;"`
while [ $M -lt $N ]
    do
    if [ $I -eq 256 ]; then J=$((J+1));I=0;fi
    NEWIP="$IP.$J.$I"
    I=$((I+1))
    M=$((M+1))
    mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "insert into IPMASTER (SUBID,IPADDRESS,STATUS) values ($SUBID,INET_ATON('$NEWIP'),0);"
    ip addr add $NEWIP/$S dev $INT
    #touch /etc/network/interfaces.d/${NEWIP}
    #   echo "auto $INT" >> /etc/network/interfaces.d/${NEWIP}
    #echo "iface $INT inet static" >> /etc/network/interfaces.d/${NEWIP}
    #echo "address ${NEWIP}" >> /etc/network/interfaces.d/${NEWIP}
    #echo "netmask 255.255.255.255" >> /etc/network/interfaces.d/${NEWIP}
    done
}
Menu_2()
{
SUBIDS=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETID FROM SUBNETS;"`
for SUBID in ${SUBIDS}
do
#mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETNAME,INET_NTOA(IPADDRESS) as FREE_IP FROM SUBNETS LEFT JOIN IPMASTER ON SUBID=SUBNETS.SUBNETID WHERE SUBNETID=$SUBID AND STATUS IS FALSE;"
mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETNAME,COUNT(IPADDRESS) as FREE_IP FROM SUBNETS LEFT JOIN IPMASTER ON SUBID=SUBNETS.SUBNETID WHERE SUBNETID=$SUBID AND STATUS IS FALSE;"
done
}
Menu_3()
{
read -p "Enter Username: " username
read -p "Enter Password: " password
if [ -z "$username" ] || [ -z "$password" ];then
echo "Missing Input details"
return
fi
#Check Duplicate Username
USERCOUNT=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT COUNT(*) FROM USERMASTER WHERE USERNAME='$username';"`
if [ $USERCOUNT -eq 1 ];then
echo "Username already exist"
return
fi
mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "INSERT INTO USERMASTER (username,password) VALUES ('$username','$password');"
    /usr/bin/htpasswd -b $PASSWDMASTER $username $password
}
Menu_4()
{
while true
do
        mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERNAME FROM USERMASTER;"
        read -p "Enter Username:" username
if [ -z "$username" ]
then
echo "Please fill missing details"
continue
else
break
fi
done
        userid=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERID FROM USERMASTER WHERE USERNAME='$username';"`
        if [ -z $userid ]; then echo "$username Doesn't EXIST!!"; exit 22;fi
        password=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT PASSWORD FROM USERMASTER WHERE USERNAME='$username';"`

SUBIDS=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETID FROM SUBNETS;"`
echo "Available SUBNETS:"
for SUBID in ${SUBIDS}
do
#mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETNAME,INET_NTOA(IPADDRESS) as FREE_IP FROM SUBNETS LEFT JOIN IPMASTER ON SUBID=SUBNETS.SUBNETID WHERE SUBNETID=$SUBID AND STATUS IS FALSE;"
mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETID,SUBNETNAME,COUNT(IPADDRESS) as FREE_IP FROM SUBNETS LEFT JOIN IPMASTER ON SUBID=SUBNETS.SUBNETID WHERE SUBNETID=$SUBID AND STATUS IS FALSE;"
done
read -p "Enter \"SUBNET ID\" listed above from where you need to assign proxies:" SUBID
        COUNTOFIP=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT COUNT(IPADDRESS) as FREE_IP FROM SUBNETS LEFT JOIN IPMASTER ON SUBID=SUBNETS.SUBNETID WHERE SUBNETID=$SUBID AND STATUS IS FALSE;"`
        #COUNTOFIP=`echo $COUNTOFIP | wc -w`

        echo "Total Available proxies: $COUNTOFIP"
        read -p "Enter Number of proxies to create: " PXYNO
if [ -z "$PXYNO" ];then echo "Missing INputs";return;fi
        if [ $COUNTOFIP -lt $PXYNO ]; then echo "Not enough available proxies to serve";return;fi

while true
do       
	read -p "Enter Port Number [ Max 4 PORTS can be added ]:" PXYPORT
	if [ -z "$PXYPORT" ];then echo "Missing INputs";return;fi
	read -p "Do you need to add another Port [ Y/N ]:" ADDPORT
	if [ "$ADDPORT" = "Y" ] || [ "$ADDPORT" = "y" ]
	then
		read -p "Enter Port Number:" PXYPORT2
		if [ -z "$PXYPORT2" ];then echo "Missing INputs";return;fi
	else
		break;
	fi
	read -p "Do you need to add another Port [ Y/N ]:" ADDPORT
	if [ "$ADDPORT" = "Y" ] || [ "$ADDPORT" = "y" ]
	then
		read -p "Enter Port Number:" PXYPORT3
		if [ -z "$PXYPORT3" ];then echo "Missing INputs";return;fi
	else
		break;
	fi
	read -p "Do you need to add another Port [ Y/N ]:" ADDPORT
	if [ "$ADDPORT" = "Y" ] || [ "$ADDPORT" = "y" ]
	then
		read -p "Enter Port Number:" PXYPORT4
		if [ -z "$PXYPORT4" ];then echo "Missing INputs";return;fi
	else
		break;
	fi
done

        EXPORTS=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT DISTINCT(PORT) FROM PROXYMASTER WHERE USERID=$userid;"`
        for EX_PORT in $EXPORTS
        do
                if [ $EX_PORT -eq $PXYPORT ];then echo "Port already exist";read -p "Enter Port Number:" PXYPORT;fi
        done
        read -p "Enter number of days:" PXYDAYS
if [ -z "$PXYDAYS" ];then echo "Missing INputs";return;fi
    LISTOFIPID=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT IPID FROM IPMASTER WHERE SUBID=$SUBID AND STATUS IS FALSE LIMIT $PXYNO;"`
    SDATE=`echo $(date +%F)`
    STIME=`echo $(date +%T)`
    EDATE=`echo $(date +%F -d "+$PXYDAYS days")`
    ETIME=`echo $(date +%T)`
    for IPID in $LISTOFIPID
    do
        mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "INSERT INTO PROXYMASTER (USERID,IPID,PORT,SDATE,STIME,EDATE,ETIME) VALUES ($userid,$IPID,$PXYPORT,'$SDATE','$STIME','$EDATE','$ETIME');"
        mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "UPDATE IPMASTER SET STATUS=1 WHERE IPID=$IPID;"
    done
	PXYID=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT PXYID FROM PROXYMASTER WHERE USERID=$userid;"`
	mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "INSERT INTO PORTMASTER (PXYID,PORT) VALUES ($PXYID,$PXYPORT);"
	if [ -n "$PXYPORT2" ];then
		mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "INSERT INTO PORTMASTER (PXYID,PORT) VALUES ($PXYID,$PXYPORT2);"
	fi
	if [ -n "$PXYPORT3" ];then
		mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "INSERT INTO PORTMASTER (PXYID,PORT) VALUES ($PXYID,$PXYPORT3);"
	fi
	if [ -n "$PXYPORT4" ];then
		mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "INSERT INTO PORTMASTER (PXYID,PORT) VALUES ($PXYID,$PXYPORT4);"
	fi
    for IPID in $LISTOFIPID
    do
		IPA=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT INET_NTOA(IPADDRESS) as IP FROM IPMASTER WHERE IPID=$IPID;"`
        echo "$IPA:$PXYPORT:$username:$password"
		if [ -n "$PXYPORT2" ];then
		echo "$IPA:$PXYPORT2:$username:$password"
		fi
		if [ -n "$PXYPORT3" ];then
			echo "$IPA:$PXYPORT3:$username:$password"
		fi
		if [ -n "$PXYPORT4" ];then
			echo "$IPA:$PXYPORT4:$username:$password"
		fi
    done

    FILENAME="${userid}_${PXYPORT}.conf"
    cd ${CONFIGDIR}/conf.d/
    touch $FILENAME
    printf "http_port $PXYPORT name=$username$PXYPORT\n" >>$FILENAME
    printf "acl ${username}_${PXYPORT} myportname $username$PXYPORT\n" >>$FILENAME
    printf "acl ${username} proxy_auth $username\n" >>$FILENAME
    for IPID in $LISTOFIPID
    do
        IPA=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT INET_NTOA(IPADDRESS) as IP FROM IPMASTER WHERE IPID=$IPID;"`
        createProxyFile "$IPA" "$PXYPORT" "$username" "$password" "$FILENAME"
    done
	
	if [ -n "$PXYPORT2" ];then
	FILENAME="${userid}_${PXYPORT2}.conf"
    cd ${CONFIGDIR}/conf.d/
    touch $FILENAME
    printf "http_port $PXYPORT2 name=$username$PXYPORT2\n" >>$FILENAME
    printf "acl ${username}_${PXYPORT2} myportname $username$PXYPORT2\n" >>$FILENAME
    printf "acl ${username} proxy_auth $username\n" >>$FILENAME
    for IPID in $LISTOFIPID
    do
        IPA=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT INET_NTOA(IPADDRESS) as IP FROM IPMASTER WHERE IPID=$IPID;"`
        createProxyFile "$IPA" "$PXYPORT2" "$username" "$password" "$FILENAME"
    done
	fi
	
	if [ -n "$PXYPORT3" ];then
	FILENAME="${userid}_${PXYPORT3}.conf"
    cd ${CONFIGDIR}/conf.d/
    touch $FILENAME
    printf "http_port $PXYPORT3 name=$username$PXYPORT3\n" >>$FILENAME
    printf "acl ${username}_${PXYPORT3} myportname $username$PXYPORT3\n" >>$FILENAME
    printf "acl ${username} proxy_auth $username\n" >>$FILENAME
    for IPID in $LISTOFIPID
    do
        IPA=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT INET_NTOA(IPADDRESS) as IP FROM IPMASTER WHERE IPID=$IPID;"`
        createProxyFile "$IPA" "$PXYPORT3" "$username" "$password" "$FILENAME"
    done
	fi
	
	if [ -n "$PXYPORT4" ];then
	FILENAME="${userid}_${PXYPORT4}.conf"
    cd ${CONFIGDIR}/conf.d/
    touch $FILENAME
    printf "http_port $PXYPORT4 name=$username$PXYPORT4\n" >>$FILENAME
    printf "acl ${username}_${PXYPORT4} myportname $username$PXYPORT4\n" >>$FILENAME
    printf "acl ${username} proxy_auth $username\n" >>$FILENAME
    for IPID in $LISTOFIPID
    do
        IPA=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT INET_NTOA(IPADDRESS) as IP FROM IPMASTER WHERE IPID=$IPID;"`
        createProxyFile "$IPA" "$PXYPORT4" "$username" "$password" "$FILENAME"
    done
	fi
    systemctl reload squid
}
Menu_5()
{
        mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERNAME FROM USERMASTER;"
        read -p "Enter Username:" username
if [ -z "$username" ];then
echo "Missing Inputs"
return
fi
        userid=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERID FROM USERMASTER WHERE USERNAME='$username';"`
        if [ -z $userid ]; then echo "No $username exist"; return;fi
        mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e  "select INET_NTOA(IPADDRESS) as IP,P.PORT,USERNAME,PASSWORD FROM USERMASTER U inner join PROXYMASTER X on U.USERID=X.USERID inner join IPMASTER I on X.IPID=I.IPID inner join PORTMASTER P on P.PXYID=X.PXYID where U.USERNAME='$username';"
        PROXIES=`mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e  "select INET_NTOA(IPADDRESS) as IP,P.PORT,USERNAME,PASSWORD,EDATE FROM USERMASTER U inner join PROXYMASTER X on U.USERID=X.USERID inner join IPMASTER I on X.IPID=I.IPID inner join PORTMASTER P on P.PXYID=X.PXYID where U.USERNAME='$username';"`
        IFS=$'\n'
        for LINE in $PROXIES; do echo $LINE | awk '{print $1":"$2":"$3":"$4}'; done
}
Menu_6()
{
        mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERNAME FROM USERMASTER;"
        read -p "Enter Username:" username
if [ -z "$username" ];then
echo "Missing Inputs"
return
fi
        userid=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERID FROM USERMASTER WHERE USERNAME='$username';"`
        if [ -z $userid ]; then echo "No $username exist"; exit 22;fi

        echo "USER  : $username"
        echo "EXPIRY"
        mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "select INET_NTOA(IPADDRESS) as IP,EDATE FROM IPMASTER I INNER JOIN PROXYMASTER X ON X.IPID=I.IPID WHERE X.USERID=$userid;"
        read -p "Enter New Expiry Date [2019-12-25]:" NEWEXPDATE
if [ -z "$NEWEXPDATE" ];then
echo "Missing Inputs"
return
fi
date "+%d/%m/%Y" -d "$NEWEXPDATE" > /dev/null  2>&1
is_valid=$?
if [ $is_valid -eq 0 ];then
mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "UPDATE PROXYMASTER SET EDATE='$NEWEXPDATE' WHERE USERID='$userid';"
fi
}
Menu_7()
{
SUBIDS=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETID FROM SUBNETS;"`
for SUBID in ${SUBIDS}
do
mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "select SUBNETID,SUBNETNAME,INET_NTOA(IPADDRESS) AS STARTING_IP from SUBNETS left join IPMASTER ON SUBNETS.SUBNETID=IPMASTER.SUBID WHERE SUBNETID=$SUBID ORDER BY IPADDRESS ASC LIMIT 1;"
done
    INT=`cat ${CONFIG_FILE} | grep INTERFACE | awk -F"=" '{print $2}'`
    echo "Please Enter IP Address Block Details"
    read -p "Enter Starting IP address:" IPBLK
    read -p "Enter total number of IP :" N
    read -p "Enter Subnet[21|22|23|24]:" S
#S=24
if [ -z "$IPBLK" ] || [ -z "$N" ] || [ -z "$S" ] ;then echo "Missing Inputs";return;fi
    J=`echo ${IPBLK} | cut -f3 -d.`
    IP=`echo ${IPBLK} | cut -f1,2 -d.`
    M=0
    I=`echo ${IPBLK} | cut -f4 -d.`
    while [ $M -lt $N ]
    do
    if [ $I -eq 256 ]; then J=$((J+1));I=0;fi
    NEWIP="$IP.$J.$I"
    I=$((I+1))
    M=$((M+1))
    mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "delete from IPMASTER where IPADDRESS=INET_ATON('$NEWIP');"
    ip addr del $NEWIP/$S dev $INT 1>/dev/null 2>/dev/null
    #rm -rf /etc/network/interfaces.d/${NEWIP} 2>/dev/null
    done
SUBIDS=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT SUBNETID FROM SUBNETS;"`
for SUBID in ${SUBIDS}
do
SUBNETNULL=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "select INET_NTOA(IPADDRESS) AS STARTING_IP from SUBNETS left join IPMASTER ON SUBNETS.SUBNETID=IPMASTER.SUBID WHERE SUBNETID=$SUBID ORDER BY IPADDRESS ASC LIMIT 1;"`
if [ "${SUBNETNULL}" = "NULL" ];then
mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "DELETE FROM SUBNETS WHERE SUBNETID='$SUBID';"
fi
done
}
Menu_8()
{
        mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERNAME FROM USERMASTER;"
        read -p "Enter Username:" username

        userid=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERID FROM USERMASTER WHERE USERNAME='$username';"`
        if [ -z "$userid" ];then echo "User $username Doesn't EXIST!!!";return;fi
        ipids=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "select IPID from PROXYMASTER where USERID=$userid;"`
		PXYID=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "select PXYID from PROXYMASTER where USERID=$userid limit 1;"`
        for IPID in $ipids
        do
                mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "DELETE from PROXYMASTER WHERE IPID=$IPID;"
				mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "DELETE from PORTMASTER WHERE PXYID=$PXYID;"
                mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e "UPDATE IPMASTER SET STATUS=0 WHERE IPID=$IPID;"
        done
        rm -rf /etc/squid/conf.d/${userid}_*.conf
        systemctl reload squid
}
Menu_9()
{
    mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERNAME FROM USERMASTER;"
    read -p "Enter Username: " username
if [ -z "$username" ];then return;fi
UCOUNT=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT COUNT(*) FROM USERMASTER LEFT JOIN PROXYMASTER ON PROXYMASTER.USERID=USERMASTER.USERID WHERE USERNAME='$username';"`
    if [ $UCOUNT -gt 1 ];then
echo "Proxies exist for this user. use option 9 and Remove Proxies from User"
return
fi
mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "DELETE from USERMASTER WHERE USERNAME='$username';"
    echo "User: $username DELETED!!!!"
    /usr/bin/htpasswd -D ${PASSWDMASTER} $username
}
Menu_10()
{
        echo "Shutting down.."
        systemctl stop squid
        echo "Proxy is DOWN now"
}
Menu_11()
{
        echo "Starting Proxy.."
        systemctl start squid
        if [ `echo $?` -eq 0 ]
        then
                echo "Proxy is UP now"
        else
                echo "Proxy Configuration error"
        fi
}
Menu_12()
{
        mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT INET_NTOA(IPADDRESS) as FREE_IP FROM IPMASTER WHERE STATUS IS FALSE;" > /root/availableip.txt
        echo "Available IP's exported to /root/availableip.txt"

}
Menu_13()
{
mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERNAME FROM USERMASTER;"
    read -p "Enter Username to export:" username
    userid=`mysql -N -h localhost -u $MYSQLUSER  $MYSQLDB -e "SELECT USERID FROM USERMASTER WHERE USERNAME='$username';"`
    if [ -z $userid ]; then echo "No $username exist"; return;fi
    mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e  "select INET_NTOA(IPADDRESS) as IP,P.PORT,USERNAME,PASSWORD FROM USERMASTER U inner join PROXYMASTER X on U.USERID=X.USERID inner join IPMASTER I on X.IPID=I.IPID inner join PORTMASTER P on P.PXYID=X.PXYID where U.USERNAME='$username';"
    PROXIES=`mysql -h localhost -u $MYSQLUSER  $MYSQLDB -e  "select INET_NTOA(IPADDRESS) as IP,P.PORT,USERNAME,PASSWORD FROM USERMASTER U inner join PROXYMASTER X on U.USERID=X.USERID inner join IPMASTER I on X.IPID=I.IPID inner join PORTMASTER P on P.PXYID=X.PXYID where U.USERNAME='$username';"`
    IFS=$'\n'
>/root/${username}.txt
chmod 600 /root/${username}.txt
    for LINE in $PROXIES; do echo $LINE | awk '{print $1":"$2":"$3":"$4}' |tee -a /root/${username}.txt; done
echo "User Proxies exported to /root/${username}.txt"
read "Press any Key to continue"
}
Menu_14()
{
echo "Format: youtube.com"
        read -p "Enter URL to add in blacklist: " blackurl
if [ -z "$blackurl" ];then
echo "Missing INputs"
return
fi
        echo ".${blackurl}" >> $BLACKLIST
        echo "$blackurl added to Blacklist Category"
                systemctl reload squid
}
Menu_15()
{
        echo "Following URL's are in Blacklist Category"
        cat $BLACKLIST
}
Menu_16()
{
        echo "Following URL's are in Blacklist Category"
        cat $BLACKLIST
        read -p "Enter URL to be removed from Blacklist: " whiteurl
if [ -z "$whiteurl" ];then
echo "Missing INputs"
return
fi
        cat $BLACKLIST | grep -v $whiteurl > newblacklist
        mv newblacklist $BLACKLIST
                systemctl reload squid
}
getMenuInput()
{
        read -p "Select an option from above menu: " MenuAnswer
        case ${MenuAnswer} in
        1)
        Menu_1
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        2)
        Menu_2
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        3)
        Menu_3
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        4)
        Menu_4
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        5)
        Menu_5
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        6)
        Menu_6
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        7)
        Menu_7
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        8)
        Menu_8
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        9)
        Menu_9
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        10)
        Menu_10
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        11)
        Menu_11
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        12)
        Menu_12
		printMenu
        getMenuInput
        ;;
        13)
        Menu_13
		printMenu
        getMenuInput
        ;;
        14)
        Menu_14
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        15)
        Menu_15
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
        16)
        Menu_16
        read -p "Press any key to continue" KEY
        printMenu
        getMenuInput
        ;;
		17)
        exit 0
        ;;
		*)
        printMenu
		getMenuInput
        ;;
        esac

}
checkRoot
checkOS
checkSquid
printMenu
getMenuInput